import { Patient, Doctor, Appointment, MedicalRecord, Department } from '../types';
import { User, SystemSettings, AuditLog } from '../types';

export const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'John Smith',
    age: 45,
    gender: 'male',
    phone: '+1-555-0123',
    email: 'john.smith@email.com',
    address: '123 Main St, City, State 12345',
    bloodGroup: 'A+',
    emergencyContact: '+1-555-0124',
    admissionDate: '2024-01-15',
    status: 'active',
    assignedDoctor: 'Dr. Sarah Johnson',
    department: 'Cardiology'
  },
  {
    id: '2',
    name: 'Emily Davis',
    age: 32,
    gender: 'female',
    phone: '+1-555-0125',
    email: 'emily.davis@email.com',
    address: '456 Oak Ave, City, State 12345',
    bloodGroup: 'B-',
    emergencyContact: '+1-555-0126',
    admissionDate: '2024-01-20',
    status: 'critical',
    assignedDoctor: 'Dr. Michael Chen',
    department: 'Emergency'
  },
  {
    id: '3',
    name: 'Robert Wilson',
    age: 58,
    gender: 'male',
    phone: '+1-555-0127',
    email: 'robert.wilson@email.com',
    address: '789 Pine St, City, State 12345',
    bloodGroup: 'O+',
    emergencyContact: '+1-555-0128',
    admissionDate: '2024-01-18',
    status: 'active',
    assignedDoctor: 'Dr. Lisa Anderson',
    department: 'Orthopedics'
  }
];

export const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialization: 'Cardiologist',
    department: 'Cardiology',
    phone: '+1-555-1001',
    email: 'sarah.johnson@elkamedicare.com',
    experience: 12,
    availability: 'available',
    patientsCount: 24,
    rating: 4.8
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialization: 'Emergency Medicine',
    department: 'Emergency',
    phone: '+1-555-1002',
    email: 'michael.chen@elkamedicare.com',
    experience: 8,
    availability: 'busy',
    patientsCount: 18,
    rating: 4.6
  },
  {
    id: '3',
    name: 'Dr. Lisa Anderson',
    specialization: 'Orthopedic Surgeon',
    department: 'Orthopedics',
    phone: '+1-555-1003',
    email: 'lisa.anderson@elkamedicare.com',
    experience: 15,
    availability: 'available',
    patientsCount: 31,
    rating: 4.9
  }
];

export const mockAppointments: Appointment[] = [
  {
    id: '1',
    patientId: '1',
    patientName: 'John Smith',
    doctorId: '1',
    doctorName: 'Dr. Sarah Johnson',
    date: '2024-01-25',
    time: '10:00 AM',
    type: 'consultation',
    status: 'scheduled',
    notes: 'Regular cardiac checkup'
  },
  {
    id: '2',
    patientId: '2',
    patientName: 'Emily Davis',
    doctorId: '2',
    doctorName: 'Dr. Michael Chen',
    date: '2024-01-25',
    time: '2:30 PM',
    type: 'emergency',
    status: 'completed',
    notes: 'Chest pain evaluation'
  }
];

export const mockMedicalRecords: MedicalRecord[] = [
  {
    id: '1',
    patientId: '1',
    patientName: 'John Smith',
    doctorId: '1',
    doctorName: 'Dr. Sarah Johnson',
    date: '2024-01-20',
    diagnosis: 'Hypertension',
    treatment: 'Lifestyle changes and medication',
    medications: ['Lisinopril 10mg', 'Metoprolol 25mg'],
    notes: 'Patient responding well to treatment',
    followUpDate: '2024-02-20'
  }
];

export const mockDepartments: Department[] = [
  {
    id: '1',
    name: 'Cardiology',
    head: 'Dr. Sarah Johnson',
    doctorCount: 5,
    patientCount: 28,
    bedCount: 20,
    availableBeds: 3,
    description: 'Specialized in heart and cardiovascular conditions'
  },
  {
    id: '2',
    name: 'Emergency',
    head: 'Dr. Michael Chen',
    doctorCount: 8,
    patientCount: 45,
    bedCount: 15,
    availableBeds: 2,
    description: 'Emergency care and trauma services'
  },
  {
    id: '3',
    name: 'Orthopedics',
    head: 'Dr. Lisa Anderson',
    doctorCount: 6,
    patientCount: 32,
    bedCount: 25,
    availableBeds: 8,
    description: 'Bone, joint, and musculoskeletal treatments'
  }
];

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@elkamedicare.com',
    role: 'admin',
    department: 'Administration',
    status: 'active',
    lastLogin: '2024-01-25T10:30:00Z',
    createdAt: '2024-01-01T00:00:00Z',
    permissions: ['all']
  },
  {
    id: '2',
    name: 'Dr. Sarah Johnson',
    email: 'sarah.johnson@elkamedicare.com',
    role: 'doctor',
    department: 'Cardiology',
    status: 'active',
    lastLogin: '2024-01-25T09:15:00Z',
    createdAt: '2024-01-10T00:00:00Z',
    permissions: ['patients:read', 'patients:write', 'records:read', 'records:write']
  },
  {
    id: '3',
    name: 'Nurse Mary Wilson',
    email: 'mary.wilson@elkamedicare.com',
    role: 'nurse',
    department: 'Emergency',
    status: 'active',
    lastLogin: '2024-01-25T08:45:00Z',
    createdAt: '2024-01-15T00:00:00Z',
    permissions: ['patients:read', 'appointments:read', 'appointments:write']
  },
  {
    id: '4',
    name: 'John Receptionist',
    email: 'john.reception@elkamedicare.com',
    role: 'receptionist',
    department: 'Front Desk',
    status: 'active',
    lastLogin: '2024-01-24T17:30:00Z',
    createdAt: '2024-01-20T00:00:00Z',
    permissions: ['appointments:read', 'appointments:write', 'patients:read']
  }
];

export const mockSystemSettings: SystemSettings = {
  hospitalName: 'Elka Medicare Hospital',
  hospitalAddress: '123 Healthcare Ave, Medical City, MC 12345',
  hospitalPhone: '+1-555-MEDICARE',
  hospitalEmail: 'info@elkamedicare.com',
  timezone: 'America/New_York',
  currency: 'USD',
  language: 'English',
  backupFrequency: 'daily',
  maintenanceMode: false,
  emailNotifications: true,
  smsNotifications: true
};

export const mockAuditLogs: AuditLog[] = [
  {
    id: '1',
    userId: '2',
    userName: 'Dr. Sarah Johnson',
    action: 'UPDATE',
    resource: 'Patient Record',
    timestamp: '2024-01-25T10:15:00Z',
    ipAddress: '192.168.1.100',
    details: 'Updated medical record for patient John Smith'
  },
  {
    id: '2',
    userId: '3',
    userName: 'Nurse Mary Wilson',
    action: 'CREATE',
    resource: 'Appointment',
    timestamp: '2024-01-25T09:30:00Z',
    ipAddress: '192.168.1.101',
    details: 'Scheduled new appointment for Emily Davis'
  },
  {
    id: '3',
    userId: '1',
    userName: 'Admin User',
    action: 'UPDATE',
    resource: 'System Settings',
    timestamp: '2024-01-25T08:00:00Z',
    ipAddress: '192.168.1.50',
    details: 'Updated hospital contact information'
  },
  {
    id: '4',
    userId: '4',
    userName: 'John Receptionist',
    action: 'VIEW',
    resource: 'Patient List',
    timestamp: '2024-01-25T07:45:00Z',
    ipAddress: '192.168.1.102',
    details: 'Accessed patient directory'
  }
];